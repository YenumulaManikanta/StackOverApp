package com.pawana;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StackOverApplication {

	public static void main(String[] args) {
		SpringApplication.run(StackOverApplication.class, args);
	}

}
